<?php
require_once __DIR__ . '/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property App</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="/phpfinal/assets/css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="/phpfinal/index.php">Property App</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <?php if(is_authenticated()): ?>
                <li class="nav-item"><a class="nav-link" href="/phpfinal/user/profile.php">Profile</a></li>
                <li class="nav-item"><a class="nav-link" href="/phpfinal/user/logout.php">Logout</a></li>
                <?php if (is_admin()): ?>
                    <li class="nav-item"><a class="nav-link" href="/phpfinal/admin/dashboard.php">Admin</a></li>
                <?php endif; ?>
            <?php else: ?>
                <li class="nav-item"><a class="nav-link" href="/phpfinal/user/login.php">Login</a></li>
                <li class="nav-item"><a class="nav-link" href="/phpfinal/user/register.php">Register</a></li>
                <li class="nav-item"><a class="nav-link" href="/phpfinal/admin/login.php">Admin Login</a></li>
                <li class="nav-item"><a class="nav-link" href="/phpfinal/admin/register.php">Admin Register</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
<div class="container mt-4">