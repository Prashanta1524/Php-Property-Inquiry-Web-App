<?php
session_start();
require_once __DIR__ . '/../config.php';

function escape($string){
    global $conn;
    return mysqli_real_escape_string($conn ,trim($string));
}

function is_authenticated() {
    return isset($_SESSION['user_id']);
}

function is_admin() {
    return isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'admin';
}

function redirect($location){
    header("Location: " . $location);
    exit();
}

function get_property_by_id($id)
{
    global $conn;
    $query = "SELECT * FROM properties WHERE property_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function get_user_by_id($id)
{
    global $conn;
    $query = "SELECT * FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}
?>