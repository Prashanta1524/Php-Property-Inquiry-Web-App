<?php
require_once __DIR__ . '/../includes/header.php';

if (!is_authenticated()) {
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
global $conn;

$query = "SELECT properties.* FROM properties 
          JOIN favorites ON properties.property_id = favorites.property_id 
          WHERE favorites.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<link rel="stylesheet" href="css/profile.css">
<div class="container mt-5">
    <h2 class="mb-4">My Favorite Properties</h2>
    <div class="row">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="../assets/img/<?= $row['image_path'] ?>" class="card-img-top" alt="<?= $row['title'] ?>" height="200px">
                        <div class="card-body">
                            <h5 class="card-title"><?= $row['title'] ?></h5>
                            <p class="card-text"><?= substr($row['description'],0,100) ?>...</p>
                            <p class="card-text"><strong>Price:</strong> $<?= $row['price'] ?></p>
                            <p class="card-text"><strong>Location:</strong> <?= $row['location'] ?></p>
                            <a href="inquiry.php?property_id=<?= $row['property_id'] ?>" class="btn btn-primary">Inquire</a>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "<p>No favorite properties found.</p>";
        }
        ?>
    </div>

    <?php
    $query = "SELECT inquiries.*, properties.title FROM inquiries 
              JOIN properties ON inquiries.property_id = properties.property_id 
              WHERE inquiries.user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    ?>

    <h2 class="mb-4">My Inquiries</h2>
    <div class="row">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                ?>
                <div class="col-md-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Property: <?= $row['title'] ?></h5>
                            <p class="card-text"><strong>Message:</strong> <?= $row['message'] ?></p>
                            <p class="card-text"><strong>Reply:</strong> <?= isset($row['reply']) ? $row['reply'] : 'No reply yet' ?></p> <!-- Check if 'reply' key exists -->
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "<p>No inquiries found.</p>";
        }
        ?>
    </div>
</div>
<?php require_once dirname(__DIR__).'/includes/footer.php'; ?>