<?php
require_once dirname(__DIR__).'/includes/functions.php';

if (!is_authenticated()) {
    redirect('login.php');
}

if (isset($_GET['property_id']) && isset($_GET['action'])) {
    $property_id = escape($_GET['property_id']);
    $action = escape($_GET['action']);
    $user_id = $_SESSION['user_id'];
    global $conn;

    if ($action == 'add') {
        $query = "INSERT INTO favorites (user_id, property_id) VALUES (?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ii", $user_id, $property_id);
        if ($stmt->execute()) {
            echo "<script>alert('Added to favorites'); window.location.href = '../index.php';</script>";
        } else {
            echo "Error adding to favorites.";
        }
    } elseif ($action == 'remove') {
        $query = "DELETE FROM favorites WHERE user_id = ? AND property_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ii", $user_id, $property_id);
        if ($stmt->execute()) {
            echo "<script>alert('Removed from favorites'); window.location.href = 'profile.php';</script>";
        } else {
             echo "Error removing from favorites.";
        }
    }
} else {
    echo "Invalid request.";
}
?>