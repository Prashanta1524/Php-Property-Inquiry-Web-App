<?php
require_once __DIR__ . '/../includes/functions.php';

if (!is_authenticated()) {
    redirect('login.php');
}

$property_id = isset($_GET['property_id']) ? intval($_GET['property_id']) : 0;
$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($property_id > 0 && $action == 'add') {
    global $conn;
    $user_id = $_SESSION['user_id'];
    $query = "INSERT INTO favorites (user_id, property_id) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $user_id, $property_id);
    if ($stmt->execute()) {
        redirect('profile.php');
    } else {
        echo "Failed to add to favorites";
    }
} else {
    redirect('profile.php');
}
?>
