<?php
require_once __DIR__ . '/../includes/header.php';

// ...existing code...

?>
<link rel="stylesheet" href="css/settings.css">
<div class="container mt-5">
    <!-- ...existing code... -->
</div>
<?php require_once dirname(__DIR__).'/includes/footer.php'; ?>
