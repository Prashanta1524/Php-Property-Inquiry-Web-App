<?php
require_once dirname(__DIR__).'/includes/header.php';

if (is_authenticated()) {
    redirect('../index.php');
}
$errors = [];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = escape($_POST['username']);
    $email = escape($_POST['email']);
    $password = escape($_POST['password']);
    $cpassword = escape($_POST['cpassword']);

    if (empty($username) || empty($email) || empty($password) || empty($cpassword)) {
        $errors[] = "All Field Are Required";
    }
    if ($password !== $cpassword) {
        $errors[] = "Password not match";
    }
    if (empty($errors)){
        $hashed_password = password_hash($password,PASSWORD_BCRYPT);
        global $conn;
        $query = "INSERT INTO users (username,email,password) VALUE (?,?,?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sss", $username,$email,$hashed_password);
        if ($stmt->execute()){
            redirect('login.php');
        }else{
           $errors[]="Something Went Wrong";
        }
    }
}
?>
<link rel="stylesheet" href="css/register.css">
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h2 class="mb-0">User Registration</h2>
                </div>
                <div class="card-body">
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <?php foreach ($errors as $error): ?>
                                <p><?= $error ?></p>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <form method="post">
                        <div class="form-group">
                            <label for="username">Username:</label>
                            <input type="text" name="username" id="username" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" name="email" id="email" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password:</label>
                            <input type="password" name="password" id="password" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="cpassword">Confirm Password:</label>
                            <input type="password" name="cpassword" id="cpassword" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Register</button>
                    </form>
                    <p class="mt-3 text-center">Already have an account? <a href="login.php">Login Now</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once dirname(__DIR__).'/includes/footer.php'; ?>