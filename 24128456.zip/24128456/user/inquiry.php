<?php
require_once dirname(__DIR__).'/includes/header.php';
if (!is_authenticated()) {
    redirect('login.php');
}
$errors = [];
$success = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $message = escape($_POST['message']);
    $property_id = escape($_POST['property_id']);
    $user_id = $_SESSION['user_id'];
    if (empty($message)) {
        $errors[] = "Message Required";
    }
    if (empty($errors)) {
        global $conn;
        $query = "INSERT INTO inquiries (user_id,property_id,message) VALUES (?,?,?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("iis", $user_id,$property_id,$message);
        if ($stmt->execute()){
            $success = true;
        }else {
           $errors[]="Something Went Wrong";
        }
    }

}
$property_id = isset($_GET['property_id']) ? escape($_GET['property_id']): '';
$property = get_property_by_id($property_id);
?>
    <h2 class="mb-4">Inquire About Property</h2>
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $error): ?>
                <p><?= $error ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <?php if ($success): ?>
    <div class="alert alert-success">
       <p>Inquiry Submitted Successfully</p>
    </div>
    <?php endif; ?>
    <?php if($property): ?>
<div class="card">
<img src="../assets/img/<?= $property['image_path'] ?>" class="card-img-top" alt="<?= $property['title'] ?>" height="200px">
                    <div class="card-body">
                        <h5 class="card-title"><?= $property['title'] ?></h5>
                        <p class="card-text"><?= substr($property['description'],0,100) ?>...</p>
                        <p class="card-text"><strong>Price:</strong> $<?= $property['price'] ?></p>
                        <p class="card-text"><strong>Location:</strong> <?= $property['location'] ?></p>
                        </div>
</div>
<form method="post" class="mt-4">
    <input type="hidden" value="<?= $property['property_id'] ?>" name="property_id">
    <div class="form-group">
        <label for="message">Message</label>
        <textarea name="message" id="message" class="form-control" required></textarea>
    </div>
    <button class="btn btn-primary">Submit Inquiry</button>
</form>
 <?php else: ?>
     <p>No properties found.</p>
 <?php endif ?>

<?php require_once dirname(__DIR__).'/includes/footer.php'; ?>