<?php
require_once dirname(__DIR__).'/../includes/header.php';
if (!is_admin()) {
    redirect('../index.php');
}
$errors = [];
$success = false;

if (isset($_GET['id'])){
    $property_id = escape($_GET['id']);
    $property = get_property_by_id($property_id);
}else{
    redirect("dashboard.php");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = escape($_POST['title']);
    $description = escape($_POST['description']);
    $price = escape($_POST['price']);
    $location = escape($_POST['location']);
    $is_sold = isset($_POST['is_sold']) ? 1 : 0;
    if (empty($title) || empty($description) || empty($price) || empty($location)) {
        $errors[] = "All Fields Are Required";
    }
     $image_path = $property['image_path'];
    if (!empty($_FILES["image"]["name"])) {
        $image_name = $_FILES['image']['name'];
        $image_tmp_name = $_FILES['image']['tmp_name'];
        $image_path = uniqid() . "_" . $image_name;
        $target_dir = dirname(__DIR__).'/../assets/img/';
        $target_file = $target_dir. $image_path;
        move_uploaded_file($image_tmp_name, $target_file);
    }
    if (empty($errors)) {
        global $conn;
        $query = "UPDATE properties SET title = ?, description = ?, price = ?, location = ?, image_path = ? , is_sold = ? WHERE property_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssdssii", $title, $description, $price, $location, $image_path,$is_sold, $property_id);
        if ($stmt->execute()){
            $success = true;
        }else{
             $errors[] = "Something Went Wrong";
        }
    }
}

?>
<h2 class="mb-4">Edit Property</h2>
<?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <?php foreach ($errors as $error): ?>
            <p><?= $error ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
<?php if ($success): ?>
    <div class="alert alert-success">
       <p>Property Updated Successfully</p>
    </div>
<?php endif; ?>
<?php if($property): ?>
<form method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label for="title">Title:</label>
        <input type="text" name="title" id="title" class="form-control" required value="<?= $property['title'] ?>">
    </div>
    <div class="form-group">
        <label for="description">Description:</label>
        <textarea name="description" id="description" class="form-control" required><?= $property['description'] ?></textarea>
    </div>
    <div class="form-group">
        <label for="price">Price:</label>
        <input type="number" name="price" id="price" class="form-control" step="0.01" required value="<?= $property['price'] ?>">
    </div>
    <div class="form-group">
        <label for="location">Location:</label>
        <input type="text" name="location" id="location" class="form-control" required value="<?= $property['location'] ?>">
    </div>
        <div class="form-group">
        <label for="image">Property Image</label>
        <input type="file" name="image" id="image" class="form-control-file">
    </div>
    <div class="form-check">
        <input type="checkbox" name="is_sold" id="is_sold" class="form-check-input" <?php if ($property['is_sold']){echo "checked";} ?>>
        <label class="form-check-label" for="is_sold">Sold</label>
    </div>
    <button type="submit" class="btn btn-primary mt-3