<?php
require_once __DIR__ . '/../includes/header.php';

if (!is_authenticated() || !is_admin()) {
    redirect('../user/login.php');
}

$errors = [];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = escape($_POST['title']);
    $description = escape($_POST['description']);
    $price = escape($_POST['price']);
    $location = escape($_POST['location']);
    $image_path = escape($_POST['image_path']);

    if (empty($title) || empty($description) || empty($price) || empty($location) || empty($image_path)) {
        $errors[] = "All fields are required";
    }

    if (empty($errors)) {
        global $conn;
        $query = "INSERT INTO properties (title, description, price, location, image_path) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssdss", $title, $description, $price, $location, $image_path);
        if ($stmt->execute()) {
            $success = "Property added successfully";
        } else {
            $errors[] = "Failed to add property";
        }
    }
}
?>
<h2 class="mb-4">Add Property</h2>
<?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <?php foreach ($errors as $error): ?>
            <p><?= $error ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
<?php if (!empty($success)): ?>
    <div class="alert alert-success">
        <p><?= $success ?></p>
    </div>
<?php endif; ?>
<form method="post">
    <div class="form-group">
        <label for="title">Title:</label>
        <input type="text" name="title" id="title" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="description">Description:</label>
        <textarea name="description" id="description" class="form-control" required></textarea>
    </div>
    <div class="form-group">
        <label for="price">Price:</label>
        <input type="number" name="price" id="price" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="location">Location:</label>
        <input type="text" name="location" id="location" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="image_path">Image Path:</label>
        <input type="text" name="image_path" id="image_path" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-primary">Add Property</button>
</form>

<?php require_once dirname(__DIR__).'/includes/footer.php'; ?>