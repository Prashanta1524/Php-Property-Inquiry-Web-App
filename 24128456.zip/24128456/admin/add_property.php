<?php
require_once dirname(__DIR__).'/../includes/header.php';
if (!is_admin()) {
    redirect('../index.php');
}
$errors = [];
$success = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = escape($_POST['title']);
    $description = escape($_POST['description']);
    $price = escape($_POST['price']);
    $location = escape($_POST['location']);
    $image_path = escape($_POST['image_path']);

    if (empty($title) || empty($description) || empty($price) || empty($location) || empty($image_path)) {
        $errors[] = "All Fields Are Required";
    }

    if (empty($errors)) {
        global $conn;
        $query = "INSERT INTO properties (title,description,price,location,image_path) VALUE (?,?,?,?,?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssdss", $title,$description,$price,$location,$image_path);
        if ($stmt->execute()){
           $success = true;
        }else{
            $errors[]="Something Went Wrong";
        }
    }
}

// Fetch images from the images folder
$images = array_diff(scandir(dirname(__DIR__).'/../images'), array('.', '..'));
?>
<h2 class="mb-4">Add New Property</h2>
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $error): ?>
                <p><?= $error ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
     <?php if ($success): ?>
    <div class="alert alert-success">
       <p>Property Added Successfully</p>
    </div>
    <?php endif; ?>
<form method="post">
    <div class="form-group">
        <label for="title">Title:</label>
        <input type="text" name="title" id="title" class="form-control" required>
    </div>
     <div class="form-group">
        <label for="description">Description:</label>
        <textarea name="description" id="description" class="form-control" required></textarea>
    </div>
     <div class="form-group">
        <label for="price">Price:</label>
        <input type="number" name="price" id="price" class="form-control" step="0.01" required>
    </div>
     <div class="form-group">
        <label for="location">Location:</label>
        <input type="text" name="location" id="location" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="image_path">Property Image</label>
        <select name="image_path" id="image_path" class="form-control" onchange="showImage(this.value)">
            <option value="">Select an image</option>
            <?php foreach ($images as $image): ?>
                <option value="<?= $image ?>"><?= $image ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group">
        <img id="selectedImage" src="" alt="Selected Image" style="display:none; max-width: 100%; height: auto;">
    </div>
    <button type="submit" class="btn btn-primary">Add Property</button>
</form>

<script>
function showImage(image) {
    if (image) {
        document.getElementById('selectedImage').src = '../images/' + image;
        document.getElementById('selectedImage').style.display = 'block';
    } else {
        document.getElementById('selectedImage').style.display = 'none';
    }
}
</script>

<?php require_once dirname(__DIR__).'/../includes/footer.php'; ?>