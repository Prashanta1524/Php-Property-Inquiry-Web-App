<?php
require_once __DIR__ . '/includes/functions.php';

// Check if user is not logged in and redirect to login
if (!is_authenticated()) {
    redirect('/phpfinal/user/login.php');
}
require_once __DIR__ . '/includes/header.php';
global $conn;

// Link to the new CSS file
?>
<link rel="stylesheet" href="assets/css/index.css">
<?php
$query = "SELECT * FROM properties";
$result = $conn->query($query);
?>

<h2 class="mb-4">Featured Properties</h2>
<div class="row">
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="assets/img/<?= $row['image_path'] ?>" class="card-img-top" alt="<?= $row['title'] ?>" height="200px">
                    <div class="card-body">
                        <h5 class="card-title"><?= $row['title'] ?></h5>
                        <p class="card-text"><?= substr($row['description'],0,100) ?>...</p>
                        <p class="card-text"><strong>Price:</strong> $<?= $row['price'] ?></p>
                        <p class="card-text"><strong>Location:</strong> <?= $row['location'] ?></p>
                        <a href="user/inquiry.php?property_id=<?= $row['property_id'] ?>" class="btn btn-primary">Inquire</a>
                        <?php if (is_authenticated()): ?>
                        <a href="user/favorites.php?property_id=<?= $row['property_id'] ?>&action=add" class="btn btn-success">Add Fav</a>
                        <?php endif ?>
                    </div>
                </div>
            </div>
            <?php
        }
    } else {
        echo "<p>No properties found.</p>";
    }
    ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>